%% Globale Variablen
global vSound;
vSound = 343.2 ; %Schallgeschwindigkeit
   
global A0;
    global Ax;
    global Ay;
    global Az;
    global B0;
    global Bx;
    global By;
    global Bz;
    global C0;
    global Cx;
    global Cy;
    global Cz;
    
global TimeDivs;

global SamplesPerSecond;
SamplesPerSecond = 0.0;

global temperature;
temperature = 20;
%% Settings
%MikrophoneKoordinaten
global mic0;
global mic1;
global mic2;
global mic3;
mic0 = [0 0 0];
mic1 = [1 0 0];
mic2 = [1 1 0];
mic3 = [0.5 0.5 1];







