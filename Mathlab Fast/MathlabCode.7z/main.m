clear all
Variables;
syms xn yn zn u v w;


fly = bornFly(1,1,1);
BrundleFly;








setDerivatives(TimeDivs);



%gesch�tzter Startpunkt
gM = [0.5 0.5 0.5];

%Visualisation;


%TestFile

%[gM iteration] = SolveRecursiv (gM, 0)




